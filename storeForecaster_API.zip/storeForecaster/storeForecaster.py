
### Imports
import pandas as pd
import numpy as np
import plotly.express as px
import streamlit as st

### Loading Required Data
data = pd.read_csv('streamlitProjects/storeForecaster/final_data.csv')

### Web Config
st.set_page_config(
    page_title="StoreSalesForecaster",
    layout="wide",
    initial_sidebar_state="expanded"
)

### Loading customer style sheets
with open('streamlitProjects/storeForecaster/customer_style_sheet.css') as f:
    st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)


### Website Title
st.markdown('''<div style = "background-color:rgb(39, 51, 70);"> 
<p style = "text-align: center; font-size: 1.5rem;"> Store Sales Forecaster </p> </div>''', unsafe_allow_html=True)
st.sidebar.markdown('<br>', unsafe_allow_html=True)
st.sidebar.markdown('<br>', unsafe_allow_html=True)

st.sidebar.markdown('''<div> <h4> User Input Selection: </h4> </div>''', unsafe_allow_html=True)
st.sidebar.markdown('<br>', unsafe_allow_html=True)

### Store Selection
storeId = st.sidebar.multiselect(
    "Store Selection for Forecast", tuple(data['Store Id'].unique())
    )

### Forecast Period Selection
timeP = st.sidebar.slider(
    "Select Forecast Period (In Months)", min_value = 1, max_value = 3, step = 1, value = 2
    )

### Main Body
st.markdown('<br>', unsafe_allow_html=True)
st.markdown('<br>', unsafe_allow_html=True)

col1, col2 = st.columns([1, 3])

totalForecast = np.round(data[(data['Store Id'].isin(storeId)) & (data['yearmo'].isin([i+201505 for i in list(range(1,timeP+1))]))]['Final Pred'].sum(),0)/1000
lb = str(np.round(totalForecast - totalForecast*0.3,0))+'K'
ub = str(np.round(totalForecast + totalForecast*0.3,0))+'K'



col1.markdown('''<div style="padding: 5px; background-color:#df4759; color:white; margin: 5px 2px 5px 2px; border: 2px solid rgb(39, 51, 70); border-radius: 7.5px"> 
Overall Forecast:
<h1 style = "text-align: center; color: white">%s</h1>
</div>'''%(str(np.round(totalForecast,0))+'K'), unsafe_allow_html=True)



col1.markdown('''<div style="padding: 5px; background-color:#df4759; color:white; margin: 5px 2px 5px 2px; border: 2px solid rgb(39, 51, 70); border-radius: 7.5px"> 
Forecast Error Range:
<h1 style = "text-align: center; color: white">%s</h1>
</div>'''%(str(lb)+'-'+str(ub)), unsafe_allow_html=True)


### Trend Chart

trendData = data[(data['Store Id'].isin(storeId)) & (data['yearmo'].isin([i+201505 for i in list(range(1,timeP+1))]))]
trendData = pd.concat([data[(data['Store Id'].isin(storeId)) & (data['yearmo'] <= 201505+1) & (data['yearmo'] >= 201409)], trendData])
trendData_chart = trendData.groupby(['yearmo', 'Test Flag'], as_index = False).sum()
trendData_chart['yearmo'] = trendData_chart['yearmo'].astype(str)
fig = px.line(trendData_chart, x='yearmo', y='Final Pred', height=300, color='Test Flag')

with st.container():
    col2.plotly_chart(fig , use_container_width=True)

### Export Forecast
@st.experimental_memo
def exportForecast(df):
   return df.to_csv(index=False).encode('utf-8')


csvFile = exportForecast( data[(data['Store Id'].isin(storeId)) & (data['yearmo'].isin([i+201505 for i in list(range(1,timeP+1))]))][['yearmo', 'Store Id', 'Final Pred']])
st.download_button(
   "Export Forecast",
   csvFile,
   "Store Forecast Recommendations.csv",
   "text/csv",
   key='download-csv'
)
